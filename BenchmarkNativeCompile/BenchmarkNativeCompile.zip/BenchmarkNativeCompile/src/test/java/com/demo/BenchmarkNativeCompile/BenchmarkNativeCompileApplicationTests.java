package com.demo.BenchmarkNativeCompile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BenchmarkNativeCompileApplicationTests {

	@Test
	void contextLoads() {
	}

}
