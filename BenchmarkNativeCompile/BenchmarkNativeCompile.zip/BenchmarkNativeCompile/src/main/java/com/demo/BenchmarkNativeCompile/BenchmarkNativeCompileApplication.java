package com.demo.BenchmarkNativeCompile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BenchmarkNativeCompileApplication {

	public static void main(String[] args) {
		SpringApplication.run(BenchmarkNativeCompileApplication.class, args);
	}

}
