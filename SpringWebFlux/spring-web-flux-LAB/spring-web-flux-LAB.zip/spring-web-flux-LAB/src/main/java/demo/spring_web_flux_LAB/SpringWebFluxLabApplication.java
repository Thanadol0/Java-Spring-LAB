package demo.spring_web_flux_LAB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebFluxLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebFluxLabApplication.class, args);
	}

}
