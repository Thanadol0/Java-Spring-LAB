package demo.spring_web_flux_LAB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebFluxLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
