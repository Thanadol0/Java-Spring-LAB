package demo.mockito_LAB4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockitoLab4Application {

	public static void main(String[] args) {
		SpringApplication.run(MockitoLab4Application.class, args);
	}

}
