package demo.mockito_LAB4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockitoLab4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
