package demo.mockito_LAB6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockitoLab6Application {

	public static void main(String[] args) {
		SpringApplication.run(MockitoLab6Application.class, args);
	}

}
