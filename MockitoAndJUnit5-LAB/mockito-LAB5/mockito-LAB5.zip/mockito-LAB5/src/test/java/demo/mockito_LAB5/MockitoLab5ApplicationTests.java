package demo.mockito_LAB5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockitoLab5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
