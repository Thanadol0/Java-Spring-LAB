package demo.mockito_LAB5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockitoLab5Application {

	public static void main(String[] args) {
		SpringApplication.run(MockitoLab5Application.class, args);
	}

}
