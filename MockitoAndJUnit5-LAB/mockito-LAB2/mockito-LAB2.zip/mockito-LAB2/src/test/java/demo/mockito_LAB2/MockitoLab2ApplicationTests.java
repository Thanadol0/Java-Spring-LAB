package demo.mockito_LAB2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockitoLab2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
