package demo.keycloak_LAB3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeycloakLab3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
