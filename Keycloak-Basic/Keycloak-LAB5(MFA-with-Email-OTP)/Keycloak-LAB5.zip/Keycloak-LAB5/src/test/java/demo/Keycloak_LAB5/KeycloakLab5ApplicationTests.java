package demo.Keycloak_LAB5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeycloakLab5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
