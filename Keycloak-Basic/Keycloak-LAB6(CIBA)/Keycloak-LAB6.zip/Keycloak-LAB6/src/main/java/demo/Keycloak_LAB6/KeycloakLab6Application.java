package demo.Keycloak_LAB6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeycloakLab6Application {

	public static void main(String[] args) {
		SpringApplication.run(KeycloakLab6Application.class, args);
	}

}
