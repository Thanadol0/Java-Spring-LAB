package demo.Keycloak_LAB4_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeycloakLab41ApplicationTests {

	@Test
	void contextLoads() {
	}

}
