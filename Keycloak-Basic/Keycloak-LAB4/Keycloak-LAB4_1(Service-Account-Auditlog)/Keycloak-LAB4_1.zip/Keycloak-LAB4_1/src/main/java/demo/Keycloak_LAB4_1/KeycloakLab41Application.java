package demo.Keycloak_LAB4_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeycloakLab41Application {

	public static void main(String[] args) {
		SpringApplication.run(KeycloakLab41Application.class, args);
	}

}
