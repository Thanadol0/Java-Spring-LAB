package com.demo.RedisAndAOP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisAndAopApplicationTests {

	@Test
	void contextLoads() {
	}

}
