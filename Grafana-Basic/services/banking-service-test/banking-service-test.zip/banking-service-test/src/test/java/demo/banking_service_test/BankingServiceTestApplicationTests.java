package demo.banking_service_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingServiceTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
